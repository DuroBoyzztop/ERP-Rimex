import React, { useState } from 'react';
import {
  Boxes,
  AlertTriangle,
  CheckCircle,
  TrendingDown,
  RefreshCw,
  ShoppingBag,
  Download,
  Mail,
  Send,
  History,
  CheckCircle2,
  BellRing,
  ExternalLink,
  X,
  Loader2,
} from 'lucide-react';
import { Producto, Configuracion, StockAlertLog } from '../types';

interface InventoryViewProps {
  productos: Producto[];
  config: Configuracion;
  onUpdateProducto: (producto: Producto) => void;
  stockAlertLogs?: StockAlertLog[];
  onCheckStockAlerts?: (force?: boolean) => Promise<any>;
  onTestStockAlert?: (productId?: string) => Promise<any>;
}

export const InventoryView: React.FC<InventoryViewProps> = ({
  productos,
  config,
  onUpdateProducto,
  stockAlertLogs = [],
  onCheckStockAlerts,
  onTestStockAlert,
}) => {
  const [checkingAlerts, setCheckingAlerts] = useState(false);
  const [testingAlert, setTestingAlert] = useState(false);
  const [alertStatusMsg, setAlertStatusMsg] = useState<string | null>(null);
  const [showLogsModal, setShowLogsModal] = useState(false);
  const [notifyingProductId, setNotifyingProductId] = useState<string | null>(null);

  const stockCritico = productos.filter((p) => p.Stock_Actual <= p.Stock_Mínimo);
  const stockNormal = productos.filter((p) => p.Stock_Actual > p.Stock_Mínimo);

  const valorTotalUSD = productos.reduce(
    (sum, p) => sum + p.Stock_Actual * p.Coste_Producción,
    0
  );
  const valorTotalBS = valorTotalUSD * config.Tasa_BCV;

  const handleQuickReorder = (p: Producto) => {
    const reordered: Producto = {
      ...p,
      Stock_Actual: p.Stock_Actual + 30, // Reponer 30 unidades
    };
    onUpdateProducto(reordered);
  };

  const handleTriggerCheck = async () => {
    if (!onCheckStockAlerts) return;
    setCheckingAlerts(true);
    setAlertStatusMsg(null);
    try {
      const data = await onCheckStockAlerts(true);
      setAlertStatusMsg(
        `✅ Verificación completada: Se procesaron ${data.criticalCount || stockCritico.length} productos en nivel mínimo. Notificaciones enviadas a ${config.Email_Propietario}.`
      );
    } catch (err) {
      setAlertStatusMsg('Error al conectar con el servicio de alertas.');
    } finally {
      setCheckingAlerts(false);
    }
  };

  const handleTriggerTest = async (prodId?: string) => {
    if (!onTestStockAlert) return;
    if (prodId) {
      setNotifyingProductId(prodId);
    } else {
      setTestingAlert(true);
    }
    setAlertStatusMsg(null);
    try {
      const data = await onTestStockAlert(prodId);
      setAlertStatusMsg(
        `📧 Notificación de alerta enviada con éxito a ${config.Email_Propietario} para ${data.product || 'producto'}.`
      );
    } catch (err) {
      setAlertStatusMsg('Error al enviar notificación de prueba.');
    } finally {
      setTestingAlert(false);
      setNotifyingProductId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-zinc-100 tracking-tight">Gestión Logística e Inventario</h2>
          <p className="text-xs text-zinc-400">
            Control de rotación de insumos, stock de seguridad y valoración en Maracay
          </p>
        </div>
      </div>

      {/* KPI Overview Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-zinc-900/40 border border-zinc-800 rounded-2xl p-4">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-xs font-medium">Valor Total Inventario ($)</span>
            <Boxes className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2">
            <div className="text-xl font-mono font-bold text-zinc-100">${valorTotalUSD.toFixed(2)} USD</div>
            <div className="text-[11px] text-emerald-400 font-mono font-medium mt-0.5">
              {valorTotalBS.toLocaleString('es-VE', { maximumFractionDigits: 0 })} Bs. (BCV)
            </div>
          </div>
        </div>

        <div className="bg-zinc-900/40 border border-zinc-800 rounded-2xl p-4">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-xs font-medium">Alertas de Rotura</span>
            <AlertTriangle className="w-4 h-4 text-red-400" />
          </div>
          <div className="mt-2">
            <div className="text-xl font-bold text-red-400">{stockCritico.length} Ítems Críticos</div>
            <div className="text-[11px] text-zinc-500 mt-0.5">Por debajo del stock mínimo</div>
          </div>
        </div>

        <div className="bg-zinc-900/40 border border-zinc-800 rounded-2xl p-4">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-xs font-medium">Ítems con Stock Ok</span>
            <CheckCircle className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2">
            <div className="text-xl font-bold text-emerald-400">{stockNormal.length} Ítems</div>
            <div className="text-[11px] text-zinc-500 mt-0.5">Abastecimiento adecuado</div>
          </div>
        </div>
      </div>

      {/* Backend Email Notification Service Card */}
      <div className="bg-gradient-to-r from-zinc-900 via-rose-950/20 to-zinc-900 border border-rose-500/20 rounded-2xl p-5 space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-rose-500/10 rounded-2xl border border-rose-500/20 text-rose-400">
              <BellRing className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-zinc-100">
                  Servicio Backend: Alertas Automáticas de Stock Mínimo
                </h3>
                <span className="px-2 py-0.5 text-[10px] font-bold bg-rose-500/10 text-rose-300 border border-rose-500/20 rounded-full flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-pulse" />
                  Activo en Backend
                </span>
              </div>
              <p className="text-xs text-zinc-300 mt-1">
                Envía correos electrónicos automáticos a la cuenta configurada:{' '}
                <strong className="text-rose-300 bg-rose-950/40 px-2 py-0.5 rounded font-mono">
                  {config.Email_Propietario}
                </strong>{' '}
                cuando el inventario llega a su nivel de seguridad mínimo.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
            <button
              onClick={handleTriggerCheck}
              disabled={checkingAlerts}
              className="flex-1 sm:flex-none flex items-center justify-center gap-2 bg-rose-600 hover:bg-rose-500 text-white font-bold px-4 py-2.5 rounded-xl text-xs shadow-lg shadow-rose-600/20 transition-all active:scale-95 disabled:opacity-50"
              title="Escanear inventario y despachar alertas para productos en nivel mínimo"
            >
              {checkingAlerts ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Send className="w-4 h-4" />
              )}
              <span>Verificar y Enviar Alertas</span>
            </button>

            <button
              onClick={() => handleTriggerTest()}
              disabled={testingAlert}
              className="flex-1 sm:flex-none flex items-center justify-center gap-2 bg-zinc-800 hover:bg-zinc-700 text-rose-300 border border-rose-500/30 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all active:scale-95 disabled:opacity-50"
              title="Enviar una notificación de prueba por correo"
            >
              {testingAlert ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Mail className="w-4 h-4" />
              )}
              <span>Notificación de Prueba</span>
            </button>

            <button
              onClick={() => setShowLogsModal(true)}
              className="flex items-center gap-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700/60 px-3 py-2.5 rounded-xl text-xs font-medium transition-all"
              title="Ver registro de alertas enviadas"
            >
              <History className="w-4 h-4 text-zinc-400" />
              <span>Historial ({stockAlertLogs.length})</span>
            </button>
          </div>
        </div>

        {alertStatusMsg && (
          <div className="p-3 bg-zinc-900 border border-zinc-800 rounded-xl text-xs text-zinc-200 flex items-center justify-between animate-in fade-in duration-200">
            <span>{alertStatusMsg}</span>
            <button
              onClick={() => setAlertStatusMsg(null)}
              className="text-zinc-500 hover:text-zinc-300 ml-2"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>

      {/* Critical Stock Reposition Table */}
      <div className="bg-zinc-900/40 border border-zinc-800 rounded-2xl p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-400" />
            <h3 className="text-sm font-bold text-zinc-100">Productos con Necesidad de Reposición Urgente</h3>
          </div>
          <span className="text-xs text-zinc-400">
            Umbral de seguridad: Stock Actual ≤ Stock Mínimo
          </span>
        </div>

        {stockCritico.length === 0 ? (
          <div className="p-6 text-center text-xs text-zinc-500">
            <CheckCircle className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
            ¡Excelente! Todo el catálogo cuenta con niveles de stock por encima del mínimo de seguridad.
          </div>
        ) : (
          <div className="overflow-x-auto border border-zinc-800 rounded-xl">
            <table className="w-full text-left text-xs text-zinc-300">
              <thead className="bg-zinc-900/80 text-zinc-500 uppercase text-[10px] tracking-wider border-b border-zinc-800">
                <tr>
                  <th className="p-3.5">Producto</th>
                  <th className="p-3.5">Categoría</th>
                  <th className="p-3.5">Stock Actual</th>
                  <th className="p-3.5">Mínimo Requerido</th>
                  <th className="p-3.5">Faltante Est.</th>
                  <th className="p-3.5 text-center">Acciones Logísticas & Alerta</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/60">
                {stockCritico.map((prod) => {
                  const faltante = Math.max(1, prod.Stock_Mínimo - prod.Stock_Actual + 20);
                  const isNotifying = notifyingProductId === prod.ID_Producto;
                  return (
                    <tr key={prod.ID_Producto} className="hover:bg-zinc-800/30 transition-colors">
                      <td className="p-3.5 font-bold text-zinc-100">{prod.Nombre_Producto}</td>
                      <td className="p-3.5 text-zinc-400">{prod.Categoría}</td>
                      <td className="p-3.5 font-bold text-red-400 font-mono">{prod.Stock_Actual} uds</td>
                      <td className="p-3.5 text-zinc-400 font-mono">{prod.Stock_Mínimo} uds</td>
                      <td className="p-3.5 text-amber-300 font-bold font-mono">+{faltante} uds</td>
                      <td className="p-3.5">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => handleQuickReorder(prod)}
                            className="px-2.5 py-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 rounded-lg text-[11px] font-semibold transition-all flex items-center gap-1"
                            title="Sumar +30 unidades al inventario"
                          >
                            <RefreshCw className="w-3 h-3" />
                            <span>Reponer +30</span>
                          </button>

                          <button
                            onClick={() => handleTriggerTest(prod.ID_Producto)}
                            disabled={isNotifying}
                            className="px-2.5 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/20 rounded-lg text-[11px] font-semibold transition-all flex items-center gap-1 disabled:opacity-50"
                            title={`Enviar alerta por correo de ${prod.Nombre_Producto} a ${config.Email_Propietario}`}
                          >
                            {isNotifying ? (
                              <Loader2 className="w-3 h-3 animate-spin" />
                            ) : (
                              <Mail className="w-3 h-3" />
                            )}
                            <span>Notificar Correo</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Full Logistics Inventory Table */}
      <div className="bg-zinc-900/40 border border-zinc-800 rounded-2xl p-5">
        <h3 className="text-sm font-bold text-zinc-100 mb-4">Inventario Completo de Productos</h3>

        <div className="overflow-x-auto border border-zinc-800 rounded-xl">
          <table className="w-full text-left text-xs text-zinc-300">
            <thead className="bg-zinc-900/80 text-zinc-500 uppercase text-[10px] tracking-wider border-b border-zinc-800">
              <tr>
                <th className="p-3">Producto</th>
                <th className="p-3">Categoría</th>
                <th className="p-3">Valoración ($)</th>
                <th className="p-3">Stock Actual</th>
                <th className="p-3">Stock Mínimo</th>
                <th className="p-3 text-center">Acción</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/60">
              {productos.map((p) => (
                <tr key={p.ID_Producto} className="hover:bg-zinc-800/30 transition-colors">
                  <td className="p-3 font-semibold text-zinc-100">{p.Nombre_Producto}</td>
                  <td className="p-3 text-zinc-400">{p.Categoría}</td>
                  <td className="p-3 font-mono font-bold text-emerald-400">
                    ${(p.Stock_Actual * p.Coste_Producción).toFixed(2)}
                  </td>
                  <td className="p-3 font-bold text-zinc-100 font-mono">{p.Stock_Actual} uds</td>
                  <td className="p-3 text-zinc-400 font-mono">{p.Stock_Mínimo} uds</td>
                  <td className="p-3 text-center">
                    <button
                      onClick={() => handleQuickReorder(p)}
                      className="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700/60 rounded-lg text-[11px] font-medium transition-all"
                    >
                      Sumar Insumos
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Stock Alert Audit History Modal */}
      {showLogsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl w-full max-w-3xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between p-5 border-b border-zinc-800">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-rose-500/10 text-rose-400 rounded-xl border border-rose-500/20">
                  <Mail className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-zinc-100">
                    Historial de Notificaciones de Stock Mínimo
                  </h3>
                  <p className="text-xs text-zinc-400">
                    Registro de correos automáticos enviados a {config.Email_Propietario}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowLogsModal(false)}
                className="p-1.5 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto space-y-3 flex-1">
              {stockAlertLogs.length === 0 ? (
                <div className="text-center py-10 text-zinc-500 text-xs">
                  <CheckCircle2 className="w-8 h-8 text-zinc-600 mx-auto mb-2" />
                  No hay notificaciones emitidas aún en esta sesión.
                  <div className="mt-2 text-zinc-400">
                    Las alertas se generan automáticamente cuando un producto baja de su stock mínimo al registrar pedidos o editar productos.
                  </div>
                </div>
              ) : (
                stockAlertLogs.map((log) => (
                  <div
                    key={log.id}
                    className="bg-zinc-950/60 border border-zinc-800 p-3.5 rounded-xl text-xs space-y-1.5 hover:border-zinc-700 transition-colors"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-[11px] text-zinc-400">
                      <span className="font-mono text-rose-400 font-bold">{log.productName}</span>
                      <span>{new Date(log.timestamp).toLocaleString('es-VE')}</span>
                    </div>

                    <div className="flex items-center justify-between gap-2">
                      <div className="text-zinc-200">
                        Stock: <span className="text-red-400 font-bold font-mono">{log.stockActual} uds</span> (Mínimo: {log.stockMinimo} uds)
                      </div>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          log.status === 'sent'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                            : 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                        }`}
                      >
                        {log.status === 'sent' ? 'Enviado vía Gmail' : 'Registrado (Ambient/Preview)'}
                      </span>
                    </div>

                    <div className="text-[11px] text-zinc-500 flex items-center justify-between">
                      <span>Destinatario: {log.recipient}</span>
                      <span className="italic">{log.reason}</span>
                    </div>
                  </div>
                ))
              )}
            </div>

            <div className="p-4 border-t border-zinc-800 bg-zinc-950/40 flex justify-end">
              <button
                onClick={() => setShowLogsModal(false)}
                className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-semibold text-xs rounded-xl transition-colors"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
