# Conectar el ERP con tu Google Drive / Sheets / Calendar / Docs / Gmail

## Por qué no conectaba
1. El servidor intentaba hablar con Google sin ninguna credencial (solo buscaba un token que
   en tu PC o en AI Studio nunca existe). Al fallar, devolvía **éxito falso** con un ID de hoja
   inventado (`1BD_ERP_MASTER_CHEFS_MARACAY_2026_SHEET_ID`) → por eso Google decía
   "El archivo que solicitaste no existe".
2. Por eso tampoco había un enlace a la carpeta real de Drive: el ERP nunca la había tocado.

## Solución: puente con Apps Script (usa TU cuenta, sin pantalla de consentimiento OAuth)

### Paso 1 — Agregar el puente al proyecto Apps Script (BD_ERPx)
1. Abre el proyecto BD_ERPx (el que tiene `Code.gs`).
2. Archivos → **+** → Script → nómbralo `Puente_Web` y pega el contenido de `apps-script/Puente_Web.gs`.

### Paso 2 — Token secreto
1. Genera un token en PowerShell:
   `[guid]::NewGuid().ToString('N') + [guid]::NewGuid().ToString('N')`
2. Apps Script → ⚙ Configuración del proyecto → **Propiedades del script** → Añadir:
   - **Propiedad:** `ERP_TOKEN`   ← el *nombre*, tal cual
   - **Valor:** el token generado   ← el *secreto*
   (No pegues el token en el campo de nombre.)

### Paso 3 — Autorizar permisos
En el editor elige la función `autorizarPermisos` → ▶ Ejecutar → acepta los permisos
(Drive, Sheets, Calendar, Docs, Gmail). Se hace una sola vez.

### Paso 4 — Implementar como Aplicación web
Implementar → Nueva implementación → ⚙ Aplicación web:
- Ejecutar como: **Yo**
- Quién tiene acceso: **Cualquier persona** (el token protege el acceso)
- Copia la URL que termina en `/exec`.

> Si cambias el código más adelante: Implementar → **Administrar implementaciones** → ✏ →
> Versión: **Nueva versión**. No crees una implementación nueva: cambiaría la URL.

### Paso 5 — Configurar el servidor
Copia `.env.example` a `.env.local` y completa:
```
APPS_SCRIPT_URL="https://script.google.com/macros/s/.../exec"
APPS_SCRIPT_TOKEN="el mismo valor de ERP_TOKEN"
GEMINI_API_KEY="tu clave de Gemini"
```
En **Google AI Studio** no se usa `.env.local`: agrega esos tres valores en el panel **Secrets**.

### Paso 6 — Verificar
```
Invoke-RestMethod "http://localhost:3000/api/workspace/status?check=1"
```
Debe mostrar `mode: apps-script` y `reachable: True`. Luego, en la pestaña Workspace, pulsa
**Sincronizar ERP completo**: aparecerán los botones **Carpeta Drive** y el enlace a la hoja real.

## Qué cambió en el código
- `workspace.ts` (nuevo): integración real; si falta la conexión devuelve un error claro (HTTP 503), nunca éxito falso.
- `server.ts`: usa `workspace.ts`; carga `.env.local` (antes `GEMINI_API_KEY` no se leía en local); el chat/análisis
  de IA ya no inventa respuestas cuando falla.
- Hojas: parser CSV real (antes `split(',')` desalineaba columnas en textos con comas).
- Recibos: el IVA se desglosa del total (antes se sumaba dos veces) y Calendar usa la hora de Caracas.
- Gmail: Para = cliente, CC = administración; asunto con tildes/emoji codificado correctamente; se bloquea el
  correo de relleno `cliente@ejemplo.com`.
- Interfaz: el estado "Conectado" ahora es real; los errores se muestran en pantalla; botón "Carpeta Drive".
- `package.json`: `vite` duplicado eliminado; se quitó `bun.lock` (usas npm).

## Pendiente a tener en cuenta
Los datos del ERP viven en memoria del servidor: al reiniciar `npm run dev` se pierden los registros creados
desde la interfaz que no hayas sincronizado con la hoja.
