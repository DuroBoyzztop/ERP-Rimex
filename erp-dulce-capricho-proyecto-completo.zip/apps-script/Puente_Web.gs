/**
 * ============================================================================
 * PUENTE_WEB.gs — Web App que conecta el ERP (localhost:3000 / AI Studio)
 * con Google Sheets, Drive, Calendar, Docs y Gmail usando TU cuenta.
 *
 * Se agrega como archivo NUEVO en el mismo proyecto de Code.gs (BD_ERPx).
 * Reutiliza CONFIG, SPREADSHEET_ID y getOrCreateFolderStructure() de Code.gs.
 *
 * IMPORTANTE: aquí NO se usa SpreadsheetApp.getUi() (no existe en Web Apps).
 * ============================================================================
 */

const PUENTE_NOMBRE_PROP_TOKEN = 'ERP_TOKEN'; // NOMBRE de la propiedad (el valor secreto va en Propiedades del script)

function doGet() {
  return respuesta_({ success: true, servicio: 'ERP Dulce Capricho', hora: new Date().toISOString() });
}

function doPost(e) {
  try {
    const req = JSON.parse(e.postData.contents);
    const esperado = PropertiesService.getScriptProperties().getProperty(PUENTE_NOMBRE_PROP_TOKEN);
    if (!esperado) throw new Error('Falta la propiedad de script ' + PUENTE_NOMBRE_PROP_TOKEN + ' (Configuración del proyecto → Propiedades del script).');
    if (req.token !== esperado) throw new Error('Token inválido.');

    const p = req.payload || {};
    switch (req.action) {
      case 'ping':         return respuesta_({ success: true, pong: true });
      case 'sync':         return respuesta_(webSync_(p));
      case 'calendar':     return respuesta_(webCalendar_(p));
      case 'receipt':      return respuesta_(webReceipt_(p));
      case 'invoiceEmail': return respuesta_(webInvoiceEmail_(p));
      case 'email':        return respuesta_(webEmail_(p));
      default: throw new Error('Acción desconocida: ' + req.action);
    }
  } catch (err) {
    return respuesta_({ success: false, error: String(err && err.message ? err.message : err) });
  }
}

function respuesta_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

/** Ejecuta esta función UNA VEZ desde el editor para aceptar todos los permisos. */
function autorizarPermisos() {
  const f = getOrCreateFolderStructure();
  CalendarApp.getDefaultCalendar();
  GmailApp.getAliases();
  Logger.log('Autorizado. Carpeta raíz: ' + f.root.getUrl());
}

// ---------------------------------------------------------------------------
// 1) Sincronizar las hojas del ERP
// ---------------------------------------------------------------------------
function webSync_(p) {
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    const ss = getTargetSpreadsheet();
    const sheets = p.sheets || {};

    Object.keys(sheets).forEach(function (nombre) {
      const filas = sheets[nombre];
      if (!filas || !filas.length) return;
      const ancho = Math.max.apply(null, filas.map(function (r) { return r.length; }));
      const rect = filas.map(function (r) {
        const c = r.slice();
        while (c.length < ancho) c.push('');
        return c;
      });

      let hoja = ss.getSheetByName(nombre) || ss.insertSheet(nombre);
      hoja.clearContents();
      hoja.getRange(1, 1, rect.length, ancho).setValues(rect);

      const enc = hoja.getRange(1, 1, 1, ancho);
      enc.setBackground('#0f172a').setFontColor('#ffffff').setFontWeight('bold').setHorizontalAlignment('center');
      hoja.setFrozenRows(1);
      hoja.autoResizeColumns(1, ancho);
    });

    const carpetas = getOrCreateFolderStructure();
    moverACarpeta_(DriveApp.getFileById(ss.getId()), carpetas.sheets);

    return {
      success: true,
      sheetId: ss.getId(),
      sheetUrl: ss.getUrl(),
      folderUrl: carpetas.root.getUrl(),
      hojas: Object.keys(sheets).length,
    };
  } finally {
    lock.releaseLock();
  }
}

// ---------------------------------------------------------------------------
// 2) Calendar (10:00 a. m. hora de Caracas, UTC-4 sin horario de verano)
// ---------------------------------------------------------------------------
function webCalendar_(p) {
  let inicio;
  if (p.date && /^\d{4}-\d{2}-\d{2}$/.test(p.date)) inicio = new Date(p.date + 'T10:00:00-04:00');
  else inicio = new Date(p.date || Date.now());
  if (isNaN(inicio.getTime())) inicio = new Date();
  const fin = new Date(inicio.getTime() + 60 * 60 * 1000);

  const ev = CalendarApp.getDefaultCalendar().createEvent(
    p.title || ('🍰 Entrega Pedido ' + p.orderId),
    inicio,
    fin,
    {
      description: 'Pedido: ' + p.orderId + '\nCliente: ' + (p.customerName || '') + '\nNotas: ' + (p.notes || '') +
        '\nTasa BCV: ' + (p.tasaBcv || CONFIG.TASA_BCV) + ' Bs/$',
      location: 'Maracay, Estado Aragua, Venezuela',
    }
  );
  ev.addEmailReminder(1440);
  ev.addPopupReminder(120);

  // El ID del evento sirve para abrirlo directamente en Calendar
  const eid = Utilities.base64EncodeWebSafe(ev.getId().split('@')[0] + ' ' + Session.getActiveUser().getEmail()).replace(/=+$/, '');
  return { success: true, eventId: ev.getId(), htmlLink: 'https://calendar.google.com/calendar/event?eid=' + eid };
}

// ---------------------------------------------------------------------------
// 3) Recibo en Google Docs, guardado en 02_Facturas_y_Comprobantes_Docs
// ---------------------------------------------------------------------------
function webReceipt_(p) {
  const tasa = Number(p.tasaBcv) || CONFIG.TASA_BCV;
  const ivaPct = Number(p.ivaPct) || CONFIG.IVA_PERCENT;
  const total = Number(p.amount) || 0;           // el importe YA incluye IVA
  const base = total / (1 + ivaPct / 100);
  const iva = total - base;
  const ref = p.invoiceId || p.orderId || 'S/N';

  const doc = DocumentApp.create('Factura Oficial #' + ref + ' - Master Chefs Dulce Capricho');
  const body = doc.getBody();
  body.appendParagraph('🍰 MASTER CHEFS - DULCE CAPRICHO C.A.').setHeading(DocumentApp.ParagraphHeading.HEADING1);
  body.appendParagraph('RIF: ' + CONFIG.RIF + ' | ' + CONFIG.UBICACION);
  body.appendParagraph('Email: ' + CONFIG.EMAIL_ADMIN);
  body.appendParagraph('COMPROBANTE DE VENTA').setHeading(DocumentApp.ParagraphHeading.HEADING2);
  body.appendParagraph('Referencia: ' + ref + ' | Fecha: ' + Utilities.formatDate(new Date(), 'America/Caracas', 'dd/MM/yyyy'));
  body.appendParagraph('Cliente: ' + (p.customerName || 'Cliente'));
  body.appendParagraph('Detalle: ' + (p.items || ''));
  body.appendParagraph('Base imponible: $' + base.toFixed(2) + ' USD');
  body.appendParagraph('IVA (' + ivaPct + '%): $' + iva.toFixed(2) + ' USD');
  body.appendParagraph('TOTAL: $' + total.toFixed(2) + ' USD').editAsText().setBold(true);
  body.appendParagraph('Tasa BCV: ' + tasa + ' Bs/$  →  TOTAL EN BOLÍVARES: ' + (total * tasa).toFixed(2) + ' Bs.');
  doc.saveAndClose();

  const carpetas = getOrCreateFolderStructure();
  moverACarpeta_(DriveApp.getFileById(doc.getId()), carpetas.invoices);

  return { success: true, docId: doc.getId(), docUrl: doc.getUrl(), folderUrl: carpetas.invoices.getUrl() };
}

// ---------------------------------------------------------------------------
// 4) Gmail: Para = cliente, CC = administración
// ---------------------------------------------------------------------------
function webInvoiceEmail_(p) {
  if (!p.customerEmail || p.customerEmail.indexOf('@') < 0) throw new Error('Correo de cliente inválido.');
  const tasa = Number(p.tasaBcv) || CONFIG.TASA_BCV;
  const total = Number(p.amount) || 0;
  const owner = p.ownerEmail || CONFIG.EMAIL_ADMIN;

  const html =
    '<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;padding:24px;border:1px solid #ddd;border-radius:12px">' +
    '<h2 style="color:#ec4899;text-align:center">🍰 Master Chefs - Dulce Capricho</h2>' +
    '<p>Estimado(a) <strong>' + html_(p.customerName || 'Cliente') + '</strong>, esta es su factura <strong>' + html_(p.invoiceId) + '</strong>.</p>' +
    '<p>Total: <strong>$' + total.toFixed(2) + ' USD</strong><br>Tasa BCV: ' + tasa + ' Bs/$<br>' +
    'Total en Bs.: <strong>' + (total * tasa).toFixed(2) + '</strong></p>' +
    (p.docUrl ? '<p><a href="' + html_(p.docUrl) + '">Abrir recibo en Google Docs</a></p>' : '') +
    '</div>';

  GmailApp.sendEmail(p.customerEmail, 'Factura Oficial #' + p.invoiceId + ' - Master Chefs Dulce Capricho', 'Factura ' + p.invoiceId, {
    htmlBody: html,
    cc: owner,
    name: 'Master Chefs Dulce Capricho',
  });
  return { success: true };
}

// ---------------------------------------------------------------------------
// 5) Correo HTML genérico (alertas de stock bajo, etc.)
// ---------------------------------------------------------------------------
function webEmail_(p) {
  if (!p.to || p.to.indexOf('@') < 0) throw new Error('Destinatario inválido.');
  GmailApp.sendEmail(p.to, p.subject || 'Aviso ERP', 'Aviso del ERP Dulce Capricho', {
    htmlBody: p.html || '',
    cc: p.cc || '',
    name: 'Master Chefs Dulce Capricho',
  });
  return { success: true };
}

// ---------------------------------------------------------------------------
// Utilidades
// ---------------------------------------------------------------------------
function moverACarpeta_(archivo, carpeta) {
  try {
    archivo.moveTo(carpeta);
  } catch (e) {
    Logger.log('No se pudo mover ' + archivo.getName() + ': ' + e);
  }
}

function html_(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}
