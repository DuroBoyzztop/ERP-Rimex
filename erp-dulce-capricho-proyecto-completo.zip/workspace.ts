/**
 * Integración Google Workspace para el ERP Dulce Capricho.
 *
 * Dos modos, en orden de prioridad:
 *  1. 'apps-script': el servidor llama a una Web App de Google Apps Script
 *     (APPS_SCRIPT_URL + APPS_SCRIPT_TOKEN). El script corre con TU cuenta de
 *     Google, así que tiene acceso real a Sheets, Drive, Calendar, Docs y Gmail.
 *  2. 'oauth': REST directo con un token de acceso (cabecera Bearer o
 *     GOOGLE_ACCESS_TOKEN). Útil solo si ya tienes un token con los scopes.
 *
 * Si no hay ninguno, se lanza WorkspaceError con instrucciones. NUNCA se
 * simula un éxito: antes, un fallo devolvía un ID de hoja inventado.
 */

export type WorkspaceMode = 'apps-script' | 'oauth' | 'none';

export class WorkspaceError extends Error {
  status: number;
  hint?: string;
  constructor(status: number, message: string, hint?: string) {
    super(message);
    this.status = status;
    this.hint = hint;
  }
}

const TZ = 'America/Caracas';
const TZ_OFFSET = '-04:00'; // Venezuela no usa horario de verano

export function getMode(bearer?: string): WorkspaceMode {
  if (process.env.APPS_SCRIPT_URL && process.env.APPS_SCRIPT_TOKEN) return 'apps-script';
  if (bearer || process.env.GOOGLE_ACCESS_TOKEN) return 'oauth';
  return 'none';
}

export function bearerFrom(header?: string): string | undefined {
  return header && header.startsWith('Bearer ') ? header.slice(7) : undefined;
}

export function driveFolderUrlFromEnv(): string {
  if (process.env.DRIVE_FOLDER_URL) return process.env.DRIVE_FOLDER_URL;
  if (process.env.DRIVE_FOLDER_ID) return `https://drive.google.com/drive/folders/${process.env.DRIVE_FOLDER_ID}`;
  return '';
}

const NO_CONFIG_HINT =
  'Configura APPS_SCRIPT_URL y APPS_SCRIPT_TOKEN en .env.local (ver LEEME_GOOGLE.md). ' +
  'Sin ellos el ERP no puede escribir en tu Google Drive/Sheets.';

// ---------------------------------------------------------------------------
// Modo 1: puente Apps Script
// ---------------------------------------------------------------------------
async function callAppsScript(action: string, payload: unknown): Promise<any> {
  const url = process.env.APPS_SCRIPT_URL as string;
  const token = process.env.APPS_SCRIPT_TOKEN as string;

  let res: Response;
  try {
    res = await fetch(url, {
      method: 'POST',
      redirect: 'follow',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ token, action, payload }),
      signal: AbortSignal.timeout(90_000),
    });
  } catch (e: any) {
    throw new WorkspaceError(504, `No se pudo contactar con Apps Script: ${e?.message || e}`);
  }

  const text = await res.text();
  let json: any;
  try {
    json = JSON.parse(text);
  } catch {
    throw new WorkspaceError(
      502,
      'Apps Script no devolvió JSON (probablemente pidió inicio de sesión o la URL es incorrecta).',
      'Reimplementa la Web App con "Ejecutar como: Yo" y "Quién tiene acceso: Cualquier persona", y usa la URL que termina en /exec.'
    );
  }
  if (!json.success) {
    throw new WorkspaceError(502, json.error || 'Apps Script devolvió un error sin detalle.');
  }
  return json;
}

// ---------------------------------------------------------------------------
// Modo 2: REST directo con token
// ---------------------------------------------------------------------------
function authHeaders(token: string) {
  return { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };
}

async function must(res: Response, what: string) {
  if (res.ok) return res;
  const body = await res.text().catch(() => '');
  const hint =
    res.status === 401 || res.status === 403
      ? 'El token no es válido o no tiene los permisos (scopes) necesarios. Usa el modo Apps Script.'
      : undefined;
  throw new WorkspaceError(res.status === 401 || res.status === 403 ? 401 : 502, `${what} falló (${res.status}): ${body.slice(0, 300)}`, hint);
}

function sheetNotation(name: string) {
  return `'${name.replace(/'/g, "''")}'!A1`;
}

async function restSync(token: string, sheets: Record<string, unknown[][]>, sheetId?: string) {
  const h = authHeaders(token);
  let id = sheetId || '';
  if (!id) {
    const r = await must(
      await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
        method: 'POST',
        headers: h,
        body: JSON.stringify({
          properties: { title: 'BD ERP - Master Chefs' },
          sheets: Object.keys(sheets).map((title) => ({ properties: { title } })),
        }),
      }),
      'Crear hoja de cálculo'
    );
    id = ((await r.json()) as { spreadsheetId: string }).spreadsheetId;
  } else {
    // Asegura que existan todas las pestañas
    const meta = await must(
      await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${id}?fields=sheets.properties.title`, { headers: h }),
      'Leer hoja de cálculo'
    );
    const existing = new Set(
      ((await meta.json()) as { sheets: { properties: { title: string } }[] }).sheets.map((s) => s.properties.title)
    );
    const missing = Object.keys(sheets).filter((n) => !existing.has(n));
    if (missing.length) {
      await must(
        await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${id}:batchUpdate`, {
          method: 'POST',
          headers: h,
          body: JSON.stringify({ requests: missing.map((title) => ({ addSheet: { properties: { title } } })) }),
        }),
        'Crear pestañas'
      );
    }
  }

  await must(
    await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${id}/values:batchClear`, {
      method: 'POST',
      headers: h,
      body: JSON.stringify({ ranges: Object.keys(sheets).map((n) => `'${n.replace(/'/g, "''")}'`) }),
    }),
    'Limpiar pestañas'
  );
  await must(
    await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${id}/values:batchUpdate`, {
      method: 'POST',
      headers: h,
      body: JSON.stringify({
        valueInputOption: 'USER_ENTERED',
        data: Object.entries(sheets).map(([name, values]) => ({ range: sheetNotation(name), values })),
      }),
    }),
    'Escribir datos'
  );
  return { sheetId: id, sheetUrl: `https://docs.google.com/spreadsheets/d/${id}/edit`, folderUrl: driveFolderUrlFromEnv() };
}

function eventDateTime(date?: string): { start: string; end: string } {
  // 'YYYY-MM-DD' -> 10:00 a. m. hora de Caracas; si trae hora, se respeta.
  let start: Date;
  if (date && /^\d{4}-\d{2}-\d{2}$/.test(date)) start = new Date(`${date}T10:00:00${TZ_OFFSET}`);
  else start = new Date(date || Date.now());
  if (isNaN(start.getTime())) start = new Date();
  return { start: start.toISOString(), end: new Date(start.getTime() + 3_600_000).toISOString() };
}

const esc = (s: unknown) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!));

const money = (n: number) => n.toLocaleString('es-VE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/** El importe de la factura YA incluye IVA: se desglosa, no se vuelve a sumar. */
export function desgloseIva(total: number, ivaPct: number) {
  const base = total / (1 + ivaPct / 100);
  return { base, iva: total - base, total };
}

function mimeSubject(s: string) {
  return `=?UTF-8?B?${Buffer.from(s, 'utf-8').toString('base64')}?=`;
}

// ---------------------------------------------------------------------------
// API pública usada por server.ts
// ---------------------------------------------------------------------------
export interface WsCtx {
  bearer?: string;
  tasaBcv: number;
  ivaPct: number;
  ownerEmail: string;
}

export async function syncSheets(ctx: WsCtx, sheets: Record<string, unknown[][]>, sheetId?: string) {
  const mode = getMode(ctx.bearer);
  if (mode === 'apps-script') {
    const r = await callAppsScript('sync', { sheets });
    return { sheetId: r.sheetId as string, sheetUrl: r.sheetUrl as string, folderUrl: (r.folderUrl as string) || '' };
  }
  if (mode === 'oauth') return restSync((ctx.bearer || process.env.GOOGLE_ACCESS_TOKEN)!, sheets, sheetId);
  throw new WorkspaceError(503, 'Google Workspace no está conectado.', NO_CONFIG_HINT);
}

export async function createCalendarEvent(
  ctx: WsCtx,
  p: { orderId: string; date?: string; title?: string; customerName?: string; notes?: string }
) {
  const mode = getMode(ctx.bearer);
  const title = p.title || `🍰 Entrega Pedido ${p.orderId} - ${p.customerName || 'Cliente'}`;
  if (mode === 'apps-script') {
    const r = await callAppsScript('calendar', { ...p, title, tasaBcv: ctx.tasaBcv });
    return { htmlLink: r.htmlLink as string, eventId: r.eventId as string };
  }
  if (mode === 'oauth') {
    const { start, end } = eventDateTime(p.date);
    const res = await must(
      await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events', {
        method: 'POST',
        headers: authHeaders((ctx.bearer || process.env.GOOGLE_ACCESS_TOKEN)!),
        body: JSON.stringify({
          summary: title,
          location: 'Maracay, Estado Aragua, Venezuela',
          description: `Pedido: ${p.orderId}\nCliente: ${p.customerName || ''}\nNotas: ${p.notes || ''}\nTasa BCV: ${ctx.tasaBcv} Bs/$`,
          start: { dateTime: start, timeZone: TZ },
          end: { dateTime: end, timeZone: TZ },
          reminders: { useDefault: false, overrides: [{ method: 'email', minutes: 1440 }, { method: 'popup', minutes: 120 }] },
        }),
      }),
      'Crear evento'
    );
    const ev = (await res.json()) as { id: string; htmlLink: string };
    return { htmlLink: ev.htmlLink, eventId: ev.id };
  }
  throw new WorkspaceError(503, 'Google Workspace no está conectado.', NO_CONFIG_HINT);
}

export async function createReceiptDoc(
  ctx: WsCtx,
  p: { orderId?: string; invoiceId?: string; customerName?: string; items?: string; amount: number }
) {
  const mode = getMode(ctx.bearer);
  if (mode === 'apps-script') {
    const r = await callAppsScript('receipt', { ...p, tasaBcv: ctx.tasaBcv, ivaPct: ctx.ivaPct });
    return { htmlLink: r.docUrl as string, documentId: r.docId as string, folderUrl: (r.folderUrl as string) || '' };
  }
  if (mode === 'oauth') {
    const token = (ctx.bearer || process.env.GOOGLE_ACCESS_TOKEN)!;
    const h = authHeaders(token);
    const ref = p.invoiceId || p.orderId || 'FAC';
    const doc = await must(
      await fetch('https://docs.googleapis.com/v1/documents', {
        method: 'POST',
        headers: h,
        body: JSON.stringify({ title: `Recibo / Factura ${ref} - Master Chefs` }),
      }),
      'Crear documento'
    );
    const documentId = ((await doc.json()) as { documentId: string }).documentId;
    const d = desgloseIva(Number(p.amount) || 0, ctx.ivaPct);
    const text =
      `MASTER CHEFS - DULCE CAPRICHO C.A.\nRIF: J-50192837-0 | Maracay, Estado Aragua, Venezuela\n\n` +
      `COMPROBANTE DE VENTA\nReferencia: ${ref}\nFecha: ${new Date().toLocaleDateString('es-VE')}\nCliente: ${p.customerName || 'Cliente'}\n\n` +
      `DETALLE:\n${p.items || '1x Pedido'}\n\n` +
      `Base imponible: $${d.base.toFixed(2)} USD\nIVA (${ctx.ivaPct}%): $${d.iva.toFixed(2)} USD\nTOTAL: $${d.total.toFixed(2)} USD\n` +
      `Tasa BCV: ${ctx.tasaBcv} Bs/$ → TOTAL EN Bs.: ${money(d.total * ctx.tasaBcv)}\n`;
    await must(
      await fetch(`https://docs.googleapis.com/v1/documents/${documentId}:batchUpdate`, {
        method: 'POST',
        headers: h,
        body: JSON.stringify({ requests: [{ insertText: { location: { index: 1 }, text } }] }),
      }),
      'Escribir documento'
    );
    return { htmlLink: `https://docs.google.com/document/d/${documentId}/edit`, documentId, folderUrl: '' };
  }
  throw new WorkspaceError(503, 'Google Workspace no está conectado.', NO_CONFIG_HINT);
}

export async function sendInvoiceEmail(
  ctx: WsCtx,
  p: { invoiceId: string; customerEmail: string; customerName?: string; amount: number; docUrl?: string }
) {
  const mode = getMode(ctx.bearer);
  if (!p.customerEmail || !p.customerEmail.includes('@') || p.customerEmail === 'cliente@ejemplo.com') {
    throw new WorkspaceError(400, 'La factura no tiene un correo de cliente válido.', 'Edita el cliente con su email real antes de enviar.');
  }
  if (mode === 'apps-script') {
    await callAppsScript('invoiceEmail', { ...p, ownerEmail: ctx.ownerEmail, tasaBcv: ctx.tasaBcv, ivaPct: ctx.ivaPct });
    return { recipients: [p.customerEmail, ctx.ownerEmail] };
  }
  if (mode === 'oauth') {
    const total = Number(p.amount) || 0;
    const html =
      `<div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;padding:24px;border:1px solid #ddd;border-radius:12px">` +
      `<h2 style="color:#ec4899;text-align:center">🍰 Master Chefs - Dulce Capricho</h2>` +
      `<p>Estimado(a) <strong>${esc(p.customerName || 'Cliente')}</strong>, esta es su factura <strong>${esc(p.invoiceId)}</strong>.</p>` +
      `<p>Total: <strong>$${total.toFixed(2)} USD</strong><br>Tasa BCV: ${ctx.tasaBcv} Bs/$<br>Total en Bs.: <strong>${money(total * ctx.tasaBcv)}</strong></p></div>`;
    const raw = [
      `To: ${p.customerEmail}`,
      `Cc: ${ctx.ownerEmail}`,
      `Subject: ${mimeSubject(`Factura Oficial #${p.invoiceId} - Master Chefs Dulce Capricho`)}`,
      'MIME-Version: 1.0',
      'Content-Type: text/html; charset=UTF-8',
      'Content-Transfer-Encoding: base64',
      '',
      Buffer.from(html, 'utf-8').toString('base64'),
    ].join('\r\n');
    await must(
      await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
        method: 'POST',
        headers: authHeaders((ctx.bearer || process.env.GOOGLE_ACCESS_TOKEN)!),
        body: JSON.stringify({ raw: Buffer.from(raw).toString('base64url') }),
      }),
      'Enviar correo'
    );
    return { recipients: [p.customerEmail, ctx.ownerEmail] };
  }
  throw new WorkspaceError(503, 'Google Workspace no está conectado.', NO_CONFIG_HINT);
}

export async function sendHtmlEmail(ctx: WsCtx, p: { to: string; subject: string; html: string; cc?: string }) {
  const mode = getMode(ctx.bearer);
  if (!p.to || !p.to.includes('@')) throw new WorkspaceError(400, 'Destinatario de correo inválido.');
  if (mode === 'apps-script') {
    const r = await callAppsScript('email', p);
    return { id: (r.messageId as string | undefined) || undefined };
  }
  if (mode === 'oauth') {
    const raw = [
      `To: ${p.to}`,
      ...(p.cc ? [`Cc: ${p.cc}`] : []),
      `Subject: ${mimeSubject(p.subject)}`,
      'MIME-Version: 1.0',
      'Content-Type: text/html; charset=UTF-8',
      'Content-Transfer-Encoding: base64',
      '',
      Buffer.from(p.html, 'utf-8').toString('base64'),
    ].join('\r\n');
    const res = await must(
      await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
        method: 'POST',
        headers: authHeaders((ctx.bearer || process.env.GOOGLE_ACCESS_TOKEN)!),
        body: JSON.stringify({ raw: Buffer.from(raw).toString('base64url') }),
      }),
      'Enviar correo'
    );
    return { id: ((await res.json()) as { id?: string }).id };
  }
  throw new WorkspaceError(503, 'Google Workspace no está conectado.', NO_CONFIG_HINT);
}

export async function pingAppsScript() {
  return callAppsScript('ping', {});
}
